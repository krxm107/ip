package brobot;

@FunctionalInterface
public interface BrobotMessenger {
    FileIOStatus sendBrobotMessage();
}
